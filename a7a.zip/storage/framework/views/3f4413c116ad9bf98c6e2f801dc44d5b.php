<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>


<?php $__env->startSection('content'); ?>
<?php if(isset($search) && $search): ?>
  <section class="search-results">
    <div class="container">
      <div class="category-header">
        <h1 class="section-title">Search results for: <?php echo e($search ?? ''); ?></h1>
        <a href="/posts" class="back-home-btn view-all">Clear Search</a>
      </div>
        <div class="posts-grid">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card">
          <img src="<?php echo e($post->cover_image ? asset('storage/' . $post->cover_image) : 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=800&q=80'); ?>" alt="<?php echo e($post->title); ?>">
          <div class="card-content">
            <h3><?php echo e($post->title); ?></h3>
            <p><?php echo Str::limit(strip_tags($post->content), 150); ?></p>
            <a href="/posts/<?php echo e($post->id); ?>">اقرأ المزيد</a>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="no-posts">No posts found for your search.</p>
        <?php endif; ?>
      </div>
    </div>
  </section>
<?php elseif(!empty($categorySlug)): ?>
  <section class="category-posts">
    <div class="container">
      <div class="category-header">
        <h1 class="section-title"> <?php echo e(ucfirst($categorySlug)); ?> Posts </h1>
        <a href="/posts" class="back-home-btn view-all">Back to Home</a>
      </div>
        <div class="posts-grid">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card">
          <img src="<?php echo e($post->cover_image ? asset('storage/' . $post->cover_image) : 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=800&q=80'); ?>" alt="<?php echo e($post->title); ?>">
          <div class="card-content">
            <h3><?php echo e($post->title); ?></h3>
            <p><?php echo Str::limit(strip_tags($post->content), 150); ?></p>
            <a href="/posts/<?php echo e($post->id); ?>">اقرأ المزيد</a>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="no-posts">No posts found in this category.</p>
        <?php endif; ?>
      </div>
    </div>
  </section>
<?php else: ?>
  <section class="hero">
    <div class="container">
      <div class="hero-box">
        <img src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=1200&q=80" alt="">
        <div class="hero-content">
          <h1>كيف تحافظ على صحتك يومياً بخطوات بسيطة وفعالة</h1>
          <p>دليل سريع للعادات الصحية، التغذية الجيدة، والنشاط البدني لتحسين جودة حياتك كل يوم.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="trending">
    <div class="container">
      <h2 class="section-title">Trending</h2>
        <div class="trending-grid">
<?php $__empty_1 = true; $__currentLoopData = $trending_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card">
            <img src="<?php echo e($post->cover_image ? asset('storage/' . $post->cover_image) : 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=800&q=80'); ?>" alt="<?php echo e($post->title); ?>">
            <div class="card-content">
                <h3><?php echo e($post->title); ?></h3>
                <p><?php echo Str::limit(strip_tags($post->content), 150); ?></p>
                <a href="/posts/<?php echo e($post->id); ?>">اقرأ المزيد</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="no-posts">No trending posts.</p>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <section class="last-show">
    <div class="container">
      <h2 class="section-title">Last Show</h2>
      <div class="trending-grid">
<?php $__empty_1 = true; $__currentLoopData = $last_show_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <div class="card">
            <img src="<?php echo e($post->cover_image ? asset('storage/' . $post->cover_image) : 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=800&q=80'); ?>" alt="<?php echo e($post->title); ?>">
            <div class="card-content">
                <h3><?php echo e($post->title); ?></h3>
                <p><?php echo Str::limit(strip_tags($post->content), 150); ?></p>
                <a href="/posts/<?php echo e($post->id); ?>">اقرأ المزيد</a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="no-posts">No last show posts.</p>
        <?php endif; ?>
      </div>
    </div>
  </section>


<?php endif; ?>

  <section class="advertisement">
    <div class="container">
      <div class="ad-box">
        <?php $__currentLoopData = $advertisements->where('placement', 'bottom'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advertisement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="ad-item">
            <?php if($advertisement->image): ?>
              <a href="<?php echo e($advertisement->link); ?>" target="_blank">
                <img src="<?php echo e(asset('storage/' . $advertisement->image)); ?>" alt="Ad Image" class="w-full h-40 object-cover rounded-md">
              </a>
            <?php endif; ?>
            <?php if($advertisement->video): ?>
              <video controls class="ad-video">
                <source src="<?php echo e(asset('storage/' . $advertisement->video)); ?>" type="video/mp4">
                Your browser does not support the video tag.
              </video>
            <?php endif; ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\newsletter\resources\views/pages/posts/index.blade.php ENDPATH**/ ?>